package com.example.grGroovy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

@Service
public class LaptopService {
	@Autowired
	LaptopDoa ld;

	public String add(Laptop l) {
		// TODO Auto-generated method stub
		return ld.add(l);
	}

	public List<Laptop> show() {
		// TODO Auto-generated method stub
		return ld.show();
	}
	
	

}
