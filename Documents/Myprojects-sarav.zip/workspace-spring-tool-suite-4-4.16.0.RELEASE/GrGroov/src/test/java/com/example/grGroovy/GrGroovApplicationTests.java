package com.example.grGroovy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrGroovApplicationTests {

	@Test
	void contextLoads() {
	}

}
