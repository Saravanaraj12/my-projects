package com.example.gradleProject2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradleProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(GradleProject2Application.class, args);
	}

}
