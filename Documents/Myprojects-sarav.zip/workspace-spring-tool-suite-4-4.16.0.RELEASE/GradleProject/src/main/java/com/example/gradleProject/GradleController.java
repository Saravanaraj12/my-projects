package com.example.gradleProject;

import org.springframework.web.bind.annotation.GetMapping;import org.springframework.web.bind.annotation.RestController;

@RestController
public class GradleController {
	
	@GetMapping("/show")
	public String show() {
		return "hi this is gradle project";
	}
	
	

}
