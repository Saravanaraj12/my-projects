package com.example.gradleProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
