package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;


@Service
public class SampleService {
@Autowired
SampleRepo sr;

public void Save(Sample s) {
	sr.save(s);
	
	
}

}
