package com.example.lap;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

@Repository
public class LaptopDoa {
	@Autowired
	LaptopRepo lr;

	public String add(Laptop l) {
		// TODO Auto-generated method stub
		lr.save(l);
		return "success";
	}

	public List<Laptop> show() {
		// TODO Auto-generated method stub
		return lr.findAll();
	}
	

}
