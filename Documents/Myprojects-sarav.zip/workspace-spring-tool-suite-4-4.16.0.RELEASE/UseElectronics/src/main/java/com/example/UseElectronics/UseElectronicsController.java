package com.example.UseElectronics;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class UseElectronicsController {
	@Autowired
	RestTemplate rt;
	
	@GetMapping(value="/tax")
	public List<UseElectronics> getTax(){
		String url1="http://localhost:8080/showall";
		String url2="http://localhost:8081/get/";
		ResponseEntity<List<UseElectronics>> response1=rt.exchange(url1,HttpMethod.GET,null,new ParameterizedTypeReference <List<UseElectronics>>() {} 
		);
		
		
		
		List<UseElectronics> t=response1.getBody();
		
		t.forEach(x->{
			int hsn=x.getHsn();
			ResponseEntity<Integer> response2=rt.exchange(url2+hsn,HttpMethod.GET,null,Integer.class);
			int tax =response2.getBody();
			x.setPrice(x.getPrice()+x.getPrice()*tax/100);
		});
		return t;
	}
	

}
