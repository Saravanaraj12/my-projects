package com.example.UseElectronics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UseElectronicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
