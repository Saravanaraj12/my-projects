package com.example.UseTeacher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class UseTeacherApplication {

	public static void main(String[] args) {
		SpringApplication.run(UseTeacherApplication.class, args);
	}
	@Bean
	public RestTemplate getRest() {
		return new RestTemplate();
	}
	

}
