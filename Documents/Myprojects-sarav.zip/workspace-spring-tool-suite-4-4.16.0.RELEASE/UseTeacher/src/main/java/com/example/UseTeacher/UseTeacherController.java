package com.example.UseTeacher;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class UseTeacherController {
	@Autowired
	RestTemplate rest;
	

	@GetMapping(value="/bonus")
	public List<UseTeacher> getbonus(){
		
		String url1="http://localhost:8080/get";
		String url2="http://localhost:8081/getbonus/";
	
	ResponseEntity<List<UseTeacher>> response1=rest.exchange(url1,HttpMethod.GET,null,new ParameterizedTypeReference<List<UseTeacher>>(){
	});
	List<UseTeacher> t=response1.getBody();
	t.forEach(x->{
	int emp=x.getEmpcode();
	
	ResponseEntity<Integer> response2=rest.exchange(url2+emp, HttpMethod.GET,null,Integer.class);
	int bonus=response2.getBody();
	
	x.setSalary(x.getSalary()+bonus);
	});
	return t;

}
}
