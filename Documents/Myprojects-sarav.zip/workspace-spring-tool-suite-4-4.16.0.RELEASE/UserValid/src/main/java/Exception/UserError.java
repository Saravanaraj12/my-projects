package Exception;


public class UserError {

	private String message;
	private int code;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public UserError(int code, String message) {
		super();
		this.message = message;
		this.code = code;
	}
	

}
