package com.example.Vehicle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BikeController {
	@Autowired
	BikeService bs;
	
	@PostMapping(value="/add")
	
	public String add(@RequestBody List<Bike> b) {
		return bs.add(b);
	}
	@GetMapping("/showAll")
	public List<Bike> showAll(){
		return bs.showAll();
	}
	@GetMapping("/showById/{a}")
	public Bike showById(@PathVariable int a){
		return bs.showById(a);
	}
	
	@GetMapping(value="/range")
	
	public List<Bike> getRange() {
		return bs.getRange();
	}
	
	@GetMapping(value="/btw/{a}/{b}")
	
	public List<Bike> getRangebt(@PathVariable int a, @PathVariable int b) {
		return bs.getRangebt(a,b);
		
	}
	@ExceptionHandler(value = BikeNotFoundException.class)
	@ResponseStatus(value = HttpStatus.CONFLICT)
	public  Error handleCustomerAlreadyExistsException(BikeNotFoundException ex)
	{
		return new Error( HttpStatus.CONFLICT.value(),ex.getMessage());
	}
	@GetMapping("/add")
	public int div() {
		int a=10;
		int b=0;
		return a/b;
	}
	
	
	

}
