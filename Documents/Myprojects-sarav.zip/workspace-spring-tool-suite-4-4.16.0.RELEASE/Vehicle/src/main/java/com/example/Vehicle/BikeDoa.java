package com.example.Vehicle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class BikeDoa {
	@Autowired
	BikeRepository br;

	public String add(List<Bike> b) {
		// TODO Auto-generated method stub
		br.saveAll(b);
		return "added successfully";
		}

	public List<Bike> getRange() {
		// TODO Auto-generated method stub
		return br.getRange();
	}

	public List<Bike> getRangebt(int a,int b) {
		// TODO Auto-generated method stub
		return br.getRangebt(a,b);
	}

	public List<Bike> showAll() {
		// TODO Auto-generated method stub
		return br.findAll();
	}
	
	

	public Bike showById(int a) {
		
	
		// TODO Auto-generated method stub
		return br.findById(a).orElseThrow(()-> new BikeNotFoundException("Typo "+a));
		}
	
	

}
