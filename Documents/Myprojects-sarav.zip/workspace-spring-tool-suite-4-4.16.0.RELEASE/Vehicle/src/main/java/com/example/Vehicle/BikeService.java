package com.example.Vehicle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class BikeService {
	@Autowired
	BikeDoa bd;

	public String add(List<Bike> b) {
		// TODO Auto-generated method stub
		return bd.add(b);
	}

	public List<Bike> getRange() {
		// TODO Auto-generated method stub
		return bd.getRange();
	}

	public List<Bike> getRangebt(int a, int b) {
		// TODO Auto-generated method stub
		return bd.getRangebt(a,b);
	}

	public List<Bike> showAll() {
		// TODO Auto-generated method stub
		return bd.showAll();
	}

	public Bike showById(int a) {
		// TODO Auto-generated method stub
		return bd.showById(a);
	}

}
