package com.example.Vehicle;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {
	
	@ExceptionHandler(value = BikeNotFoundException.class)
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	
	public @ResponseBody Error handleException(BikeNotFoundException ex)
    {
        return new Error(HttpStatus.NOT_FOUND.value(), ex.getMessage());
    }
	@ExceptionHandler(value=ArithmeticException.class)
   public @ResponseBody Error Arith(ArithmeticException e) {
	   return new Error(HttpStatus.CONFLICT.value(), e.getMessage());
	    
}
}
