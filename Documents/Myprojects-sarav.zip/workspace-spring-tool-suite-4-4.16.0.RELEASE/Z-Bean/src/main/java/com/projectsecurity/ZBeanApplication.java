package com.projectsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
@EnableConfigurationProperties
public class ZBeanApplication {
	


	public static void main(String[] args) {
		ApplicationContext ct=SpringApplication.run(ZBeanApplication.class, args);
	Pojo p=(Pojo) ct.getBean("pojo");
	System.out.println(p.toString());
		
		
		
		
	}

}
