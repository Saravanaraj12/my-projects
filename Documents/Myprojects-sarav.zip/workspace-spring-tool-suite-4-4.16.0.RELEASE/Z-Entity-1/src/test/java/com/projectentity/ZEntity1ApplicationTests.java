package com.projectentity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZEntity1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
