package com.example.useProduct;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class UseProductController {
	@Autowired
	RestTemplate restTemplate;
	@GetMapping(value="/getvalue")
	public List<UseProduct> getValue() {
		String url1="http://localhost:8080/view";
		String url2="http://localhost:8081/hsn/";
		ResponseEntity<List<UseProduct>> response1=restTemplate.exchange(url1,HttpMethod.GET,null,new ParameterizedTypeReference<List<UseProduct>>(){});
		List<UseProduct> p=response1.getBody();
		p.forEach(x->{
		int hsn=x.getHsn();
		ResponseEntity<Integer> response2=restTemplate.exchange(url2+hsn,HttpMethod.GET,null,Integer.class);
		int taxPercent=response2.getBody();
		x.setPrice(x.getPrice()+x.getPrice()*taxPercent/100);
		}
		);
		return p;
	}	
}
	


