package com.example.useProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UseProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
